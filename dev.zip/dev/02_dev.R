# Building a Prod-Ready, Robust Shiny Application.
# 
# README: each step of the dev files is optional, and you don't have to 
# fill every dev scripts before getting started. 
# 01_start.R should be filled at start. 
# 02_dev.R should be used to keep track of your development during the project.
# 03_deploy.R should be used once you need to deploy your app.
# 
# 
###################################
#### CURRENT FILE: DEV SCRIPT #####
###################################

# Engineering

## Dependencies ----
## Add one line by package you want to add as dependency
usethis::use_package( "shiny" )
usethis::use_package( "shinythemes" )
usethis::use_package( "DT" )
usethis::use_package( "purrr" )
usethis::use_package( "sf" )
usethis::use_package( "lwgeom" )
usethis::use_package( "readr" )
usethis::use_package( "tidyr" )
usethis::use_package( "dplyr" )
usethis::use_package( "magrittr" )
usethis::use_package( "xfun" )
usethis::use_package( "tibble" )
usethis::use_package( "rlang" )
usethis::use_package( "RColorBrewer" )
usethis::use_package( "leaflet" )
usethis::use_package( "stringr" )
usethis::use_package( "waiter" )
usethis::use_package( "shinyFeedback" )
usethis::use_package( "tidyselect" )
usethis::use_package( "ggplot2" )
usethis::use_package( "shinyWidgets" )
usethis::use_package( "rmarkdown" )

## Add modules ----
## Create a module infrastructure in R/
## Add modules ----
## Create a module infrastructure in R/
# golem::add_module( name = "get_layers" ) 
# golem::add_module( name = "single_input" ) 
# golem::add_module( name = "multiple_input" ) 
# golem::add_module( name = "render_dt" )
# golem::add_module( name = "get_layers_gpkg_only" )
# golem::add_module( name = "get_layers_multiple_gpkg_only" )
# golem::add_fct( "list_layers" )
# golem::add_fct( "read_tables" )
# golem::add_fct( "group_by_summarise" )
# golem::add_fct( "join_tables" )
# golem::add_fct( "spatial_join_tables" )
# golem::add_fct( "add_popups" )
# golem::add_fct( "sync_forms" )
# golem::add_fct( "add_layers_leaflet" )
# golem::add_fct( "add_layers_leaflet_no_zoom" )
# golem::add_fct( "plant_number" )
# golem::add_fct( "shannon_h_div" )

## Add helper functions ----
## Creates ftc_* and utils_*
# golem::add_fct( "helpers" ) 
# golem::add_utils( "helpers" )

## External resources
## Creates .js and .css files at inst/app/www
# golem::add_js_file( "script" )
# golem::add_js_handler( "handlers" )
# golem::add_css_file( "custom" )

## Add internal datasets ----
## If you have data in your package
# usethis::use_data_raw( name = "my_dataset", open = FALSE ) 

## Tests ----
## Add one line by test you want to create
# usethis::use_test( "app" )

# Documentation

## Vignette ----
# usethis::use_vignette("maplandscape")
# devtools::build_vignettes()
# usethis::use_vignette("demo")
usethis::use_vignette("sync_forms")
usethis::use_vignette("combine_spatial_layers")
# devtools::build_vignettes()

# usethis::use_pkgdown()
# Run to build the website
pkgdown::build_site()

## Code coverage ----
## (You'll need GitHub there)
# usethis::use_github()
# usethis::use_travis()
# usethis::use_appveyor()

# You're now set! ----
# go to dev/03_deploy.R
rstudioapi::navigateToFile("dev/03_deploy.R")

